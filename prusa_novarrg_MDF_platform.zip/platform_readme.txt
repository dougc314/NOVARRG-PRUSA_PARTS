There are 6 files 
subplate_laser.dxf and topplate_laser.dxf are the original design, with holes that are a bit big, and 4mm HW works better than 3mm HW. 

The other files have 3mm in their name and the holes were made smaller (0.12 inches)
They are saved in two versions of DXF,  Autocad 14, and Autocad 2007. Mongos software didn't like one of them, I forgot which. I suspect that it wants 2007.

These files were done in Alibre, I didn't include the original files as not too many people can use them. Unfortunatly my Autocad light '97 produces DXF files that many modren programs refuse to read. Autocad is much better at 2D drawings than Alibre is.

-Doug Crowe